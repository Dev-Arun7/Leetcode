// https://leetcode.com/problems/find-n-unique-integers-sum-up-to-zero

class Solution(object):
    def sumZero(self, n):
        """
        :type n: int
        :rtype: List[int]
        """
        a = []
        sum = 0
        for i in range(n):
            if i == n-1:
                a.append(-sum)
            else:
                a.append(i+1)
                sum = (sum + (i+1))
        return a

  
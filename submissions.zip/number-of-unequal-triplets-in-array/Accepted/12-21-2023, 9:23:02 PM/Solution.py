// https://leetcode.com/problems/number-of-unequal-triplets-in-array

class Solution:
    def unequalTriplets(self, nums: List[int]) -> int:
        l = len(nums)
        count = 0
        for i in range(l-2):
            for j in range(i+1, l-1):
                for k in range(j+1, l):
                    if nums[i] != nums[j] and nums[j] != nums[k] and nums[i] != nums[k]:
                        count += 1
        return count


        
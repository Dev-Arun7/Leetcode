// https://leetcode.com/problems/check-if-all-the-integers-in-a-range-are-covered

class Solution:
    def isCovered(self, ranges: list[list[int]], left: int, right: int) -> bool:
        total_elements = []
        for r in ranges:
            for num in range(r[0], r[1] + 1):
                total_elements.append(num)
        full_range = list(range(left,right + 1))
        for i in full_range:
            if i in total_elements:
                flag = 1
            else:
                flag = 0
                break
        if flag == 1:
            return True
        else:
            return False
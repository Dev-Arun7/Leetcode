// https://leetcode.com/problems/third-maximum-number

class Solution:
    def thirdMax(self, nums: list[int]) -> int:
        my_set = set(nums)
        if len(nums) < 3:
            return max(nums)
        else:
            for i in range(2):
                n = max(my_set)
                my_set.remove(n)
            return max(my_set)


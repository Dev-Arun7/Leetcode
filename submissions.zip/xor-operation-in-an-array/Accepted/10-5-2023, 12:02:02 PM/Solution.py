// https://leetcode.com/problems/xor-operation-in-an-array

class Solution(object):
    def xorOperation(self, n, start):
        """
        :type n: int
        :type start: int
        :rtype: int
        """
        arr = []
        for i in range(n):
            arr.append(start + 2 * i)
            if i > 0:
                arr[i] = arr[i] ^ arr[i-1]
        return arr[n-1]


 
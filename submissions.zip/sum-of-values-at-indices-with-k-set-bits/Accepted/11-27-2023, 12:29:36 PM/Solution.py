// https://leetcode.com/problems/sum-of-values-at-indices-with-k-set-bits

class Solution:
    def sumIndicesWithKSetBits(self, nums: list[int], k: int) -> int:
        total_sum = 0
        for i, num in enumerate(nums):
            binary_num = bin(i)
            if binary_num.count('1') == k:
                total_sum += num
        return total_sum


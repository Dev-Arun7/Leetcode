// https://leetcode.com/problems/check-if-a-string-is-an-acronym-of-words

class Solution:
    def isAcronym(self, words: List[str], s: str) -> bool:
        acronym = ''
        acronym = ''.join([i[0] for i in words])
        return s == acronym
        
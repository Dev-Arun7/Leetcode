// https://leetcode.com/problems/can-make-arithmetic-progression-from-sequence

class Solution(object):
    def canMakeArithmeticProgression(self, arr):
        """
        :type arr: List[int]
        :rtype: bool
        """
        arr = sorted(arr)
        temp = arr[1] - arr[0]
        for i, num in enumerate(arr[1:], 1):
            if arr[i] - arr[i-1] == temp:
                continue
            else:
                return False
        return True

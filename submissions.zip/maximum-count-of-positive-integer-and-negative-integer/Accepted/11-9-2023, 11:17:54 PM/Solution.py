// https://leetcode.com/problems/maximum-count-of-positive-integer-and-negative-integer

class Solution:
    def maximumCount(self, nums: List[int]) -> int:
        n_count = 0
        p_count = 0
        nums_set = set(nums)
        for i in nums:
            if i < 0:
                n_count += 1
            elif i > 0:
                p_count += 1
        return max(n_count, p_count)

        
// https://leetcode.com/problems/rearrange-spaces-between-words

class Solution(object):
    def reorderSpaces(self, text):
        """
        :type text: str
        :rtype: str
        """
        out = ""
        spaces = text.count(" ")
        word_list = text.split()
        num_word = len(word_list)
        
        if num_word == 1:
            out = word_list[0] + " " * spaces
            return out

        between_space = spaces // (num_word - 1)
        remaining_space = spaces - (between_space * (num_word - 1))
        
        for i in word_list:
            out += i
            if i != word_list[-1]:
                out += " " * between_space
        
        out += " " * remaining_space 
        return out
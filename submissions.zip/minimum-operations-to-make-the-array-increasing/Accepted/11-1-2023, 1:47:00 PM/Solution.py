// https://leetcode.com/problems/minimum-operations-to-make-the-array-increasing

class Solution:
    def minOperations(self, nums: list[int]) -> int:
        count = 0
        temp = 0
        for i in range(len(nums)-1):
            if nums[i] >= nums[i+1]:
                temp = (nums[i] + 1) - (nums[i + 1])
                count += temp
                nums[i+1] += temp
        return count
  
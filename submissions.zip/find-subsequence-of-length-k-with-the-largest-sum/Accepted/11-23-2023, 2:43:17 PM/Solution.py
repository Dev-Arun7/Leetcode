// https://leetcode.com/problems/find-subsequence-of-length-k-with-the-largest-sum

class Solution:
    def maxSubsequence(self, nums: List[int], k: int) -> List[int]:
        if len(nums) < k:
            return nums
        else:
            while len(nums) > k:
                smallest = min(nums)
                nums.remove(smallest)
        return nums

        
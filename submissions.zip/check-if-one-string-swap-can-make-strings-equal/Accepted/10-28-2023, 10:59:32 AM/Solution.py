// https://leetcode.com/problems/check-if-one-string-swap-can-make-strings-equal


class Solution:
    def areAlmostEqual(self, s1: str, s2: str) -> bool:
        my_list = list(s2)
        ref = list(s1)
        l =len(my_list)
        if s1 == s2:
            return True
        else:
            for i in range(l):
                for j in range(i+1,l):
                    temp = my_list[:]
                    temp[i],temp[j] = temp[j],temp[i]
                    if temp == ref:
                        return True
            return False

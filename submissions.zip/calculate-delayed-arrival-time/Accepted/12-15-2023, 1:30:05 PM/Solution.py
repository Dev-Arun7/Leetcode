// https://leetcode.com/problems/calculate-delayed-arrival-time

class Solution:
    def findDelayedArrivalTime(self, arrivalTime: int, delayedTime: int) -> int:
        sum = arrivalTime + delayedTime
        return sum % 24
        
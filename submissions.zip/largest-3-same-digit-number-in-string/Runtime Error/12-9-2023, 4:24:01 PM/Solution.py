// https://leetcode.com/problems/largest-3-same-digit-number-in-string

class Solution:
    def largestGoodInteger(self, num: str) -> str:
        good_num = ""
        temp = num[0]
        for i in num:
            if temp[-1] == i:
                temp += i
            else:
                temp = i
            if len(temp) == 3:
                if int(temp) > int(good_num):
                    good_num = temp
        return "000" if len(good_num) == 0 else good_num
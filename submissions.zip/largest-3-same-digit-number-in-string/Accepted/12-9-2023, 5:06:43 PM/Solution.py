// https://leetcode.com/problems/largest-3-same-digit-number-in-string

class Solution:
    def largestGoodInteger(self, num: str) -> str:
        good_num = ""
        sum = 0
        temp = ""
        l = len(num)
        for i in range(l-2):
            if num[i] == num[i+1] and num[i] == num[i+2]:
                temp = num[i : i+3]
                if int(temp) >= sum:
                    good_num = temp
                    sum = int(good_num)
        return good_num
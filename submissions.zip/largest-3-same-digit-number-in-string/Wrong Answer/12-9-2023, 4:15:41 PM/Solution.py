// https://leetcode.com/problems/largest-3-same-digit-number-in-string

class Solution:
    def largestGoodInteger(self, num: str) -> str:
        good_num = 0
        temp = num[0]
        for i in num:
            if temp[-1] == i:
                temp += i
            else:
                temp = i
            if len(temp) == 3:
                if int(temp) > good_num:
                    good_num = int(temp)
        return str(good_num)
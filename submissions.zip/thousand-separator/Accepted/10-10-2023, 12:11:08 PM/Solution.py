// https://leetcode.com/problems/thousand-separator

class Solution(object):
    def thousandSeparator(self, n):
        """
        :type n: int
        :rtype: str
        """
        if n == 0:
            return "0"
        
        s = ""
        count = 0
        
        while n > 0:
            d = n % 10
            n = n // 10
            s = str(d) + s
            count += 1
            
            if count % 3 == 0 and n > 0:
                s = "." + s
                
        return s

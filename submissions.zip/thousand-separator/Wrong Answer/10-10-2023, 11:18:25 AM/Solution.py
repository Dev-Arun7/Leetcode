// https://leetcode.com/problems/thousand-separator

class Solution(object):
    def thousandSeparator(self, n):
        """
        :type n: int
        :rtype: str
        """
        s = ""
        while n > 0:
            d = n % 1000
            n = n // 1000
            s = str(d) + s
            if n > 0:
                s = "." + s
        return s

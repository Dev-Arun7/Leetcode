// https://leetcode.com/problems/determine-if-string-halves-are-alike

class Solution:
    def halvesAreAlike(self, s: str) -> bool:
        referance = ["A","E","I","O","U","a","e","i","o","u"]
        count_a = 0
        count_b = 0
        l = (len(s)//2)
        a = s[:l]
        b = s[l:]
        for i in referance:
            count_a += a.count(i)
            count_b += b.count(i)
        return True if count_a == count_b else False        




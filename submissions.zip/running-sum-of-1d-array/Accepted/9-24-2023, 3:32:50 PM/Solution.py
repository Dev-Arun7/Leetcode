// https://leetcode.com/problems/running-sum-of-1d-array

class Solution(object):
    def runningSum(self, nums):
        """
        :type nums: List[int]
        :rtype: List[int]
        """
        sum = 0
        result = []
        for i, num in enumerate(nums):
            sum = sum + num
            result.append(sum)

        return result

        

// https://leetcode.com/problems/n-th-tribonacci-number

class Solution(object):
    def tribonacci(self, n):
        """
        :type n: int
        :rtype: int
        """
        a = 0
        b = 1
        c = 1
        t = 0
        for i in range(4):
            t = a+b+c
        return t
        
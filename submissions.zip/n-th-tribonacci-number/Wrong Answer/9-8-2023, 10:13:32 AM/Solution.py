// https://leetcode.com/problems/n-th-tribonacci-number

class Solution(object):
    def tribonacci(self, n):
        """
        :type n: int
        :rtype: int
        """
        a = 4
        return a
// https://leetcode.com/problems/n-th-tribonacci-number

class Solution(object):
    def tribonacci(self, n):
        """
        :type n: int
        :rtype: int
        """
        a = 0
        b = 1
        c = 1
        t = 0
        for i in range(n-2):
            t = a+b+c
            a = b
            b = c
            c = t
        return t
        
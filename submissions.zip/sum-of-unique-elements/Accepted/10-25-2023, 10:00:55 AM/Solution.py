// https://leetcode.com/problems/sum-of-unique-elements

class Solution:
    def sumOfUnique(self, nums: List[int]) -> int:
        unique_nums = [num for num in nums if nums.count(num) == 1]
        return sum(unique_nums)

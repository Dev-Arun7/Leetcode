// https://leetcode.com/problems/replace-elements-with-greatest-element-on-right-side

class Solution(object):
    def replaceElements(self, arr):
        """
        :type arr: List[int]
        :rtype: List[int]
        """
        l = len(arr)
        for i in range(l):
            if i == l-1:
                arr[i] = -1
                break 
            temp = arr[i+1]
            for j in range(i+1,l):
                if temp < arr[j]:
                    temp = arr[j]
            arr[i] = temp              
        return arr


        
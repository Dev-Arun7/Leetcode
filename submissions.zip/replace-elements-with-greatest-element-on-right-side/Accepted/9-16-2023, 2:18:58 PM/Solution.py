// https://leetcode.com/problems/replace-elements-with-greatest-element-on-right-side

class Solution(object):
    def replaceElements(self, arr):
        """
        :type arr: List[int]
        :rtype: List[int]
        """
        c = -1
        i = len(arr) - 1
        while i >= 0:
            temp = arr[i]
            arr[i] = c
            if temp > c:
                c = temp
            i -= 1
        return arr


        
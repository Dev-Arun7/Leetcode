// https://leetcode.com/problems/create-target-array-in-the-given-order

class Solution(object):
    def createTargetArray(self, nums, index):
        """
        :type nums: List[int]
        :type index: List[int]
        :rtype: List[int]
        """
        result = []
        for i, n in enumerate(index):
            result.insert(n,nums[i])

        return result
        

// https://leetcode.com/problems/maximum-repeating-substring


class Solution(object):
    def maxRepeating(self, sequence, word):
        """
        :type sequence: str
        :type word: str
        :rtype: int
        """
        count = 0
        test = True
        temp = word
        while test:
            if temp in sequence:
                count +=1
                temp = temp + word
            else:
                return count

 
        


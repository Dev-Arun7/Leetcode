// https://leetcode.com/problems/maximum-repeating-substring


class Solution(object):
    def maxRepeating(self, sequence, word):
        """
        :type sequence: str
        :type word: str
        :rtype: int
        """
        word_length = len(word)
        length = len(sequence)
        count = 0
        for i in range(length):
            temp = sequence[i:word_length + i]
            if word == temp:
                count +=1
                i+= word_length
        return count


        
        


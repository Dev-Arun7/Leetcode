// https://leetcode.com/problems/how-many-numbers-are-smaller-than-the-current-number

class Solution(object):
    def smallerNumbersThanCurrent(self, nums):
        result = []
        for i,num1 in enumerate(nums):
            count = 0
            for j,num2 in enumerate(nums):
                if num1> num2:
                    count +=1
            result.append(count)
        return result

// https://leetcode.com/problems/uncommon-words-from-two-sentences

class Solution:
    def uncommonFromSentences(self, s1: str, s2: str) -> List[str]:
        result = []
        list_s1 = s1.split()
        list_s2 = s2.split()
        set_s1 = set(list_s1)
        set_s2 = set(list_s2)
        for i in set_s1:
            if list_s1.count(i) == 1:
                if i not in list_s2:
                    result.append(i)
        for i in set_s2:
            if list_s2.count(i) == 1:
                if i not in list_s1:
                    result.append(i)
        return result        
// https://leetcode.com/problems/intersection-of-two-arrays

class Solution:
    def intersection(self, nums1: list[int], nums2: list[int]) -> list[int]:
        result_set = set()
        for i in nums1:
            if i in nums2:
                result_set.add(i)
        return list(result_set)
        
// https://leetcode.com/problems/calculate-money-in-leetcode-bank

class Solution:
    def totalMoney(self, n: int) -> int:
        total = 0
        money = 0
        for i in range(n):
            if i % 7 == 0:
                money += 1
                credit = money
            total += credit
            credit += 1
        return total
        

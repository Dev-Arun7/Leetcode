// https://leetcode.com/problems/count-of-matches-in-tournament

class Solution:
    def numberOfMatches(self, n: int) -> int:
        return n-1
        
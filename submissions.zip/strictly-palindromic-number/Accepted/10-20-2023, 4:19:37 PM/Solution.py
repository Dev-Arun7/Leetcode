// https://leetcode.com/problems/strictly-palindromic-number

class Solution:
    def isStrictlyPalindromic(self, n: int) -> bool:
        return False
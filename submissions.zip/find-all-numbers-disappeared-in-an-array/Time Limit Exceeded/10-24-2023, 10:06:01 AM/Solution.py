// https://leetcode.com/problems/find-all-numbers-disappeared-in-an-array

class Solution:
    def findDisappearedNumbers(self, nums: list[int]) -> list[int]:
        l = len(nums)
        result = []
        for i in range(1,l+1):
            if i not in nums:
                result.append(i)
        return result

        

// https://leetcode.com/problems/sorting-the-sentence

class Solution(object):
    def sortSentence(self, s):
        """
        :type s: str
        :rtype: str
        """
        words = s.split()
        l = len(words)
        temp = [None] * l
        i = 1
        while i <=l:
            lastWord = words.pop()
            lastDigit = int(lastWord[-1])
            lastWord = lastWord[:-1]
            temp[lastDigit-1] = lastWord
            i += 1
        result = " ".join(temp)
        return(result)
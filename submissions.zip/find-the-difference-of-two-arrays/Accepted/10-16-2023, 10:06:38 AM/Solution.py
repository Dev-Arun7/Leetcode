// https://leetcode.com/problems/find-the-difference-of-two-arrays

class Solution(object):
    def findDifference(self, nums1, nums2):
        """
        :type nums1: List[int]
        :type nums2: List[int]
        :rtype: List[List[int]]
        """
        result = []
        ans1 = []
        ans2 = []
        for i, num1 in enumerate(nums1):
            flag = 0
            for j, num2 in enumerate(nums2):
                if num1 == num2:
                    flag = 1
            if flag == 0:
                if num1 in ans1:
                    continue
                else:
                    ans1.append(num1)
        for i, num2 in enumerate(nums2):
            flag = 0
            for j, num1 in enumerate(nums1):
                if num2 == num1:
                    flag = 1
            if flag == 0:
                if num2 in ans2:
                    continue
                else:
                    ans2.append(num2)

        result.append(ans1)
        result.append(ans2)
        return result
                
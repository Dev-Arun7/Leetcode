// https://leetcode.com/problems/divide-a-string-into-groups-of-size-k

class Solution:
    def divideString(self, s: str, k: int, fill: str) -> list[str]:

        list_s = list(s)
        result = []
        l =  len(s)
        while l > k:
            temp = ""
            for i in range(k):
                temp += list_s.pop(0)
                l -= 1
            result.append(temp)
        if l > 0:
            temp = ""
            for i in range(k):
                if len(list_s) > 0:
                    temp += list_s.pop(0)
                else:
                    temp += fill
            result.append(temp)
        return result
                
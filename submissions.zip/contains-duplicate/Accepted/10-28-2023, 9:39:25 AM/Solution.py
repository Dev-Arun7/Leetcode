// https://leetcode.com/problems/contains-duplicate

class Solution(object):
    def containsDuplicate(self, nums):
        """
        :type nums: List[int]
        :rtype: bool
        """
        my_set = set(nums)
        set_length = len(my_set)
        nums_length = len(nums)
        return False if set_length == nums_length else True

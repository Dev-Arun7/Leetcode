// https://leetcode.com/problems/minimum-distance-to-the-target-element

class Solution:
    def getMinDistance(self, nums: list[int], target: int, start: int) -> int:
        index = nums.index(target)
        return abs(index - start)
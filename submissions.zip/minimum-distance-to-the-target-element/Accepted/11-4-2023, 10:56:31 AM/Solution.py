// https://leetcode.com/problems/minimum-distance-to-the-target-element

class Solution:
    def getMinDistance(self, nums: list[int], target: int, start: int) -> int:
        l = len(nums)
        distance = l
        for i, num in enumerate(nums):
            if num == target:
                temp = abs(start - i)
                if temp < distance:
                    distance = temp

        return distance

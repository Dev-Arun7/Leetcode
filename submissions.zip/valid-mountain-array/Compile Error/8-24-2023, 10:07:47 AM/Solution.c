// https://leetcode.com/problems/valid-mountain-array

bool validMountainArray(int* arr, int arrSize){

    int a = 0;
    int b = 0;
    int x = 0;
    int i;
    for(i = 0;i<n-1;i++)
    {
        if(x=0)
        {
            if a[i] > a[i+<]
            a++
            else
            {
                x = 1
            }
        }
        else(a[i]<a[i+1])
        {
            b++
        }
    }

    if(a+b) == (n-1)
    {
        return true   
    }
    else
    {
        return true
    }

}
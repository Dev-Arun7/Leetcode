// https://leetcode.com/problems/split-a-string-in-balanced-strings

class Solution:
    def balancedStringSplit(self, s: str) -> int:
        count = 0
        l = len(s)
        i = 0
        r_count = 0
        l_count = 0
        while i < l:
            if s[i] == "R":
                r_count += 1
            else:
                l_count += 1
            if r_count == l_count:
                count += 1
                r_count = 0
                l_count = 0
            i += 1
        return count
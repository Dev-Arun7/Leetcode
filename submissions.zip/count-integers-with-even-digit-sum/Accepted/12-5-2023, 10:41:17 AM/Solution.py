// https://leetcode.com/problems/count-integers-with-even-digit-sum

class Solution:
    def countEven(self, num: int) -> int:
        count = 0
        for i in range(1, num + 1):
            sum = 0
            temp = i
            while temp > 0:
                sum += temp % 10
                temp = temp // 10
            if sum % 2 == 0:
                count += 1
        return count
        
// https://leetcode.com/problems/count-integers-with-even-digit-sum

class Solution:
    def countEven(self, num: int) -> int:
        count 0
        for i in range(1, n + 1):
            sum = 0
            temp = i
            while temp > 0
        
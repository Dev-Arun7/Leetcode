// https://leetcode.com/problems/minimum-absolute-difference

class Solution(object):
    def minimumAbsDifference(self, arr):
        """
        :type arr: List[int]
        :rtype: List[List[int]]
        """
        result = []
        l = len(arr)
        arr.sort()
        min_diff = arr[1] - arr[0]   

        for i in range(l-1):
          diff = arr[i+1] - arr[i]
          if min_diff > diff:
            min_diff = diff
        
        for i in range(l-1):
          if arr[i+1] - arr[i] == min_diff:
            result.append([arr[i],arr[i + 1]])
        
        return result

      



        
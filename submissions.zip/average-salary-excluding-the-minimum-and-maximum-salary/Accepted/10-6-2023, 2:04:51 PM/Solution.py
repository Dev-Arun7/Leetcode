// https://leetcode.com/problems/average-salary-excluding-the-minimum-and-maximum-salary

class Solution(object):
    def average(self, salary):
        """
        :type salary: List[int]
        :rtype: float
        """
        min_salary = min(salary)
        max_salary = max(salary)
        l = len(salary)
        sum = 0
        for i in range(l-1,-1,-1):
            if salary[i] == min_salary or salary[i] == max_salary:
                salary.remove(salary[i])
            else:
                sum = sum + salary[i]

        return float(sum)/float(l-2)

        
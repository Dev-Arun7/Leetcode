// https://leetcode.com/problems/average-salary-excluding-the-minimum-and-maximum-salary

class Solution(object):
    def average(self, salary):
        """
        :type salary: List[int]
        :rtype: float
        """
        min_salary = min(salary)
        max_salary = max(salary)
        l = len(salary)
        for i in range(l-1,-1,-1)
        
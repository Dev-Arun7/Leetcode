// https://leetcode.com/problems/a-number-after-a-double-reversal

class Solution:
    def isSameAfterReversals(self, num: int) -> bool:
        digit = str(num)
        rev1 = int(digit[::-1])
        rev2 = int(str(rev1)[::-1])
        return rev2 == num
        
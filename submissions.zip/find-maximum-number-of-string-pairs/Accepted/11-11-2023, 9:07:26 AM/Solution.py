// https://leetcode.com/problems/find-maximum-number-of-string-pairs

class Solution:
    def maximumNumberOfStringPairs(self, words: List[str]) -> int:
        l = len(words)
        count = 0
        for i in range(l-1):
            for j in range(i+1,l):
                if words[i] == words[j][::-1]:
                    count += 1
        return count

        
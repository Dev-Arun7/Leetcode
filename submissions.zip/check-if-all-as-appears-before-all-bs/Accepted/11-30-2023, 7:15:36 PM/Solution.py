// https://leetcode.com/problems/check-if-all-as-appears-before-all-bs

class Solution:
    def checkString(self, s: str) -> bool:
        flag = 0
        for i in s:
            if i == "b":
                flag = 1
            if flag == 1:
                if i == "a":
                    return False
        return True
        
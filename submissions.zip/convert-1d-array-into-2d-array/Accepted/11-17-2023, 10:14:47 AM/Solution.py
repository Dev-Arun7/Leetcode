// https://leetcode.com/problems/convert-1d-array-into-2d-array

class Solution:
    def construct2DArray(self, original: list[int], m: int, n: int) -> list[list[int]]:
        d = 0
        if m * n != len(original):
            return []
        arr = [[0 for a in range(n)] for b in range(m)]
        for i in range(m):
            for j in range(n):
                arr[i][j] = original[d]
                d += 1
        return arr
        

// https://leetcode.com/problems/second-largest-digit-in-a-string


class Solution:
    def secondHighest(self, s: str) -> int:
        digits = set()
        for i, num in enumerate(s):
            if num.isdigit():
                digits.add(num)
        sorted_digits = sorted(digits)
        if len(digits) > 1:
            return int(sorted_digits[-2])
        return -1

        

// https://leetcode.com/problems/unique-number-of-occurrences

class Solution(object):
    def uniqueOccurrences(self, arr):
        """
        :type arr: List[int]
        :rtype: bool
        """
        res = []
        myset = set(arr)
        for i in myset:
            n = arr.count(i)
            if n not in res:
                res.append(n)
            else:
                return False
        return True
        
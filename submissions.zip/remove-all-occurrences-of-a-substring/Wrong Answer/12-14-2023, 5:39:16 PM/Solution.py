// https://leetcode.com/problems/remove-all-occurrences-of-a-substring

class Solution:
    def removeOccurrences(self, s: str, part: str) -> str:
        temp = s
        flag = True
        while flag:
            if part in temp:
                temp = temp.replace(part,'').strip()
            else:
                flag = False
        return temp
        
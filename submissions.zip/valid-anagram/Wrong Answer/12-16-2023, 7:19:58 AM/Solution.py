// https://leetcode.com/problems/valid-anagram

class Solution:
    def isAnagram(self, s: str, t: str) -> bool:
        flag = True
        if len(t) <= len(s):
            for i in t:
                if (i in s) and (t.count(i) <= s.count(i)):
                    continue
                else:
                    return False
        else:
            return False
        return flag

                
        
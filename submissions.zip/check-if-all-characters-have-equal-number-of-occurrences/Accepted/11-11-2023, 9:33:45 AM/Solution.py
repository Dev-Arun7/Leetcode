// https://leetcode.com/problems/check-if-all-characters-have-equal-number-of-occurrences

class Solution:
    def areOccurrencesEqual(self, s: str) -> bool:
        my_set = set(s)
        num_count = s.count(my_set.pop())
        for i in my_set:
            if s.count(i) != num_count:
                return False
        return True

        
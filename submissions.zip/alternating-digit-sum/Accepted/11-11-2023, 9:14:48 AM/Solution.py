// https://leetcode.com/problems/alternating-digit-sum

class Solution:
    def alternateDigitSum(self, n: int) -> int:
        digit_str = str(n)
        l = len(digit_str)
        sum = 0
        for i in range(l):
            if i % 2 == 0:
                sum += int(digit_str[i])
            else:
                sum -= int(digit_str[i])
        return sum
        
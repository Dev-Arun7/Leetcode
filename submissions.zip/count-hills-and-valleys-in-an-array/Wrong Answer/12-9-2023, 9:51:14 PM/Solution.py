// https://leetcode.com/problems/count-hills-and-valleys-in-an-array

class Solution:
    def countHillValley(self, nums: List[int]) -> int:
        l = len(nums)
        count = 0
        for i in range(1, l-2):
            if nums[i] == nums[i + 1]:
                nums.pop(i)
            if nums[i] > nums[i-1] and nums[i] > nums[i+1]:
                count += 1
            elif nums[i] < nums[i-1] and nums[i] < nums[i+1]:
                count += 1
        return count
        
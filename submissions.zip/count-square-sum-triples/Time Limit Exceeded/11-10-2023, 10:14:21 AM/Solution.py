// https://leetcode.com/problems/count-square-sum-triples

class Solution:
    def countTriples(self, n: int) -> int:
        count = 0
        for i in range(n + 1):
            for j in range(i):
                for k in range(i):
                    if (j ** 2) + (k ** 2) == (i ** 2):
                        count += 1
        return count

        
        
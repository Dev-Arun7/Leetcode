// https://leetcode.com/problems/count-square-sum-triples

class Solution:
    def countTriples(self, n: int) -> int:
        count = 0
        for i in range(5, n+1):
            for j in range(i):
                for k in range(j+1, i):
                    if (j ** 2) + (k ** 2) == (i ** 2):
                        count += 1
                        break
        return count * 2

        
        
// https://leetcode.com/problems/count-square-sum-triples

class Solution:
    def countTriples(self, n: int) -> int:
        count = 0
        for i in range(5, n+1):
            for j in range(i):
                for k in range(j+1, i):
                   c = (j **2) + (k **2)
                   if i == math.sqrt(c):
                       count += 1
        return count * 2

        
        
// https://leetcode.com/problems/count-common-words-with-one-occurrence

class Solution:
    def countWords(self, words1: List[str], words2: List[str]) -> int:
        count = 0
        word_set_1 = set(words1)
        word2_set_2 = set (words2)
        for i in word_set_1:
            if words1.count(i) == words2.count(i) == 1:
                count += 1
        return count

        
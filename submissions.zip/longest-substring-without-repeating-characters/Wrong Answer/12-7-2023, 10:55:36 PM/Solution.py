// https://leetcode.com/problems/longest-substring-without-repeating-characters

class Solution:
    def lengthOfLongestSubstring(self, s: str) -> int:
        longest_word = ''
        temp = ''
        for i in s:
            if i not in temp:
                temp += i
            else:
                if len(temp) > len(longest_word):
                    longest_word = temp
                _index = temp.find(i)
                temp = temp[_index-1::]
        if len(temp) > len(longest_word):
                    longest_word = temp
        return len(longest_word)
        


s = "aabaab!bb"
obj = Solution()
result = obj.lengthOfLongestSubstring(s)
print(result)

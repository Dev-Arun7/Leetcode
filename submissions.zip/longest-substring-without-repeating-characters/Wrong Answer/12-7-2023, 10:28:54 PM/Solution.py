// https://leetcode.com/problems/longest-substring-without-repeating-characters

class Solution:
    def lengthOfLongestSubstring(self, s: str) -> int:
        longest_word = ''
        temp = ''
        for i in s:
            if i not in temp:
                temp += i
            else:
                if len(temp) > len(longest_word):
                    longest_word = temp
                temp = i
        if len(temp) > len(longest_word):
                    longest_word = temp
        return len(longest_word)
        
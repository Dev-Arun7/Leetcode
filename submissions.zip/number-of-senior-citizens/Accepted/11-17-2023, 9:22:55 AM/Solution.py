// https://leetcode.com/problems/number-of-senior-citizens

class Solution:
    def countSeniors(self, details: List[str]) -> int:
        l = len(details)
        count = 0
        for i in details:
            age = ""
            temp = i
            age += temp[11]
            age += temp[12]
            if int(age) > 60:
                count += 1
        return count
        
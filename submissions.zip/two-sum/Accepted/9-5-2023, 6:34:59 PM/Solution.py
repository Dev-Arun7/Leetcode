// https://leetcode.com/problems/two-sum

class Solution(object):
    def twoSum(self, nums, target):
        """
        :type nums: List[int]
        :type target: int
        :rtype: List[int]
        """
        out = []
        l = len(nums)
        for i in range(0,l-1):
            for j in range(i+1,l):
                if nums[i]+nums[j]==target:
                    out.append(i)
                    out.append(j)
                    return out

       

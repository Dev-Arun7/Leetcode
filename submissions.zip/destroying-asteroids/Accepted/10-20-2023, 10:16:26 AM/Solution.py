// https://leetcode.com/problems/destroying-asteroids

class Solution:
    def asteroidsDestroyed(self, mass: int, asteroids: list[int]) -> bool:
        asteroids.sort()
        for i in asteroids:
            if mass >= i:
                mass = mass + i
            else:
                return False
        return True
        

// https://leetcode.com/problems/number-of-different-integers-in-a-string

class Solution:
    def numDifferentIntegers(self, word: str) -> int:
        temp = ""
        my_set = set()
        for i, char in enumerate(word):
            if char.isdigit():
                temp += char
            else:
                if temp:
                    make_int = int(temp)
                    my_set.add(make_int)
                    temp = ""
        if temp:
                make_int = int(temp)
                my_set.add(make_int)
        return len(my_set)

// https://leetcode.com/problems/maximum-69-number

class Solution(object):
    def maximum69Number (self, num):
        """
        :type num: int
        :rtype: int
        """
        temp = num
        i = 1
        value = 0
        while (temp>0):
            newNum = temp % 10
            temp = temp // 10
            if(newNum == 6):
                value = i
            i = i * 10
        return num + (value * 3)


        
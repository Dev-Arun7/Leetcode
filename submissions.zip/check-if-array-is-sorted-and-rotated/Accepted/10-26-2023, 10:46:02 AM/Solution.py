// https://leetcode.com/problems/check-if-array-is-sorted-and-rotated

class Solution:
    def check(self, nums: list[int]) -> bool:
        ref = sorted(nums)
        for i in range(len(nums)):
            n = nums.pop()
            nums.insert(0,n)
            if ref == nums:
                return True
        return False
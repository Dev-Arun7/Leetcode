// https://leetcode.com/problems/two-out-of-three

class Solution:
    def twoOutOfThree(self, nums1: List[int], nums2: List[int], nums3: List[int]) -> List[int]:
        my_set = set()
        for i in nums1:
            if i in nums2:
                my_set.add(i)
            elif i in nums3:
                my_set.add(i)

        for i in nums2:
            if i in nums1:
                my_set.add(i)
            elif i in nums3:
                my_set.add(i)

        for i in nums3:
            if i in nums1:
                my_set.add(i)
            elif i in nums1:
                my_set.add(i)

        return list(my_set)
        
                    

        
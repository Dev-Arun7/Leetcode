// https://leetcode.com/problems/special-array-with-x-elements-greater-than-or-equal-x

class Solution(object):
    def specialArray(self, nums):
        """
        :type nums: List[int]
        :rtype: int
        """
        l = len(nums)
        for i in range(l+1):
            c = 0
            for j in nums:
                if i <= j:                   
                    c += 1
            if i == c:
                return i
        return -1
        
    
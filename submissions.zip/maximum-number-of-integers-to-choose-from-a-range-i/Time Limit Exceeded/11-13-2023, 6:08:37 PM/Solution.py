// https://leetcode.com/problems/maximum-number-of-integers-to-choose-from-a-range-i

class Solution:
    def maxCount(self, banned: list[int], n: int, maxSum: int) -> int:
        sum = 0
        count = 0
        for i in range(1,n+1):
            if i not in banned:
                if sum +i <= maxSum:
                    sum += i
                    count += 1
                else:
                    return count
        return count

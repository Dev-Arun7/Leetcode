// https://leetcode.com/problems/maximum-number-of-integers-to-choose-from-a-range-i

class Solution:
    def maxCount(self, banned: list[int], n: int, maxSum: int) -> int:
        sum = 0
        count = 0
        full_set = set(range(1,n+1))
        banned_set = set(banned)
        usable_set = full_set - banned_set
        for i in usable_set:
            if sum +i <= maxSum:
                count += 1
                sum += i
            else:
                return count
        return count

       
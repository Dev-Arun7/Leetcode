// https://leetcode.com/problems/maximum-number-of-integers-to-choose-from-a-range-i

class Solution:
    def maxCount(self, banned: list[int], n: int, maxSum: int) -> int:
        _sum = 0
        count = 0
        full_set = set(range(1,n+1))
        banned_set = set(banned)
        usable_set = full_set - banned_set
        sorted_list = sorted(usable_set)
        for i in sorted_list:
            if _sum +i <= maxSum:
                count += 1
                _sum += i
            else:
                break
        return count

        
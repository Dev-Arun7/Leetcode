// https://leetcode.com/problems/smallest-even-multiple

class Solution:
    def smallestEvenMultiple(self, n: int) -> int:
        i = n
        while True:
            if i % n == 0 and i % 2 == 0:
                break
            else:
                i += n
        return i
// https://leetcode.com/problems/sum-of-digits-of-string-after-convert

import string
class Solution:
    def getLucky(self, s: str, k: int) -> int:
        lower = list(string.ascii_lowercase)
        lower.insert(0,'_')
        integer_string = ""
        sum = 0
        for i in s:
            integer_string += str(lower.index(i))
        temp = int(integer_string)
        for i in range(k):
            sum = 0
            while temp > 0:
                sum += temp % 10
                temp = temp // 10
            temp = sum
            
        return sum
      
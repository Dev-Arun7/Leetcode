// https://leetcode.com/problems/number-of-good-pairs

class Solution:
    def numIdenticalPairs(self, nums: List[int]) -> int:
        count =0
        for i, num1 in enumerate(nums):
            for j, num2 in enumerate(nums):
               if num1 == num2 and i<j:
                   count=count+1
        return count           
                   
        
// https://leetcode.com/problems/maximum-difference-between-increasing-elements

class Solution:
    def maximumDifference(self, nums: list[int]) -> int:
        temp = -1
        for i in range(len(nums)):
            for j in range(i+1, len(nums)):
                if nums[j] > nums[i] and nums[j] - nums[i] > temp:
                    temp = nums[j] - nums[i]
        return temp

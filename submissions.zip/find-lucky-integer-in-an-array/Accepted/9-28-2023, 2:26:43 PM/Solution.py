// https://leetcode.com/problems/find-lucky-integer-in-an-array

class Solution(object):
    def findLucky(self, arr):
        """
        :type arr: List[int]
        :rtype: int
        """
        temp = -1
        for i,num in enumerate(arr):
            count = arr.count(num)
            if num == count:
                if temp < count:
                    temp = count
        return temp
     

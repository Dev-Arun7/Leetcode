// https://leetcode.com/problems/percentage-of-letter-in-string

class Solution:
    def percentageLetter(self, s: str, letter: str) -> int:
        total_characters = len(s)
        letter_count = s.count(letter)
        percentage = (letter_count / total_characters) * 100
        return int(percentage)

// https://leetcode.com/problems/percentage-of-letter-in-string

class Solution:
    def percentageLetter(self, s: str, letter: str) -> int:
        l = len(s)
        _count = s.count(letter)
        return round((_count / l) * 100)
        
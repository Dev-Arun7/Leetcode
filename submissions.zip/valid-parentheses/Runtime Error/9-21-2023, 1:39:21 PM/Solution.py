// https://leetcode.com/problems/valid-parentheses

class Solution(object):
    def isValid(self, s):
        """
        :type s: str
        :rtype: bool
        """
        d= ['(',')','[',']','{','}']

        for i in range(6):
            if s[i]==d[i]:
                if s[i+1]==d[i+1]:
                    return True
                else:
                    return False
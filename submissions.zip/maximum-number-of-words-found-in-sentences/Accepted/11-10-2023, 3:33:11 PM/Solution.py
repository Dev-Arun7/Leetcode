// https://leetcode.com/problems/maximum-number-of-words-found-in-sentences

class Solution:
    def mostWordsFound(self, sentences: List[str]) -> int:
        count = 0
        words = []
        for i in sentences:
            words = i.split()
            if len(words) > count:
                count = len(words)
        return count
        
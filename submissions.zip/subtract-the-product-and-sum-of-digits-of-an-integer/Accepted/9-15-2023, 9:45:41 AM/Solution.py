// https://leetcode.com/problems/subtract-the-product-and-sum-of-digits-of-an-integer

class Solution(object):
    def subtractProductAndSum(self, n):
        """
        :type n: int
        :rtype: int
        """
        mul = 1
        sum = 0
        while n > 0:
            digit = n % 10
            mul = mul * digit
            sum = sum + digit
            n = n // 10

        result = mul - sum
        return result

        
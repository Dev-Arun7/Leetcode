// https://leetcode.com/problems/path-crossing

class Solution:
    def isPathCrossing(self, path: str) -> bool:
        ref_list = [[0,0]]
        x, y = 0, 0
        for i in path:
            if i == 'N':
                y += 1
            elif i == 'S':
                y -= 1
            elif i == 'E':
                x += 1
            else:
                x -= 1
            if [x,y] in ref_list:
                return True
            else:
                ref_list.append ([x,y])
        return False
        
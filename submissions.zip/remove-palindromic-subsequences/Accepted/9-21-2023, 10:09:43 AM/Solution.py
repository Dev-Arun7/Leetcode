// https://leetcode.com/problems/remove-palindromic-subsequences

class Solution(object):
    def removePalindromeSub(self, s):
        """
        :type s: str
        :rtype: int
        """
        return 1 if s == s[::-1] else 2
        
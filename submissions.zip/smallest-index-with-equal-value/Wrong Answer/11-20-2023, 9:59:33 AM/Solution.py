// https://leetcode.com/problems/smallest-index-with-equal-value

class Solution:
    def smallestEqual(self, nums: List[int]) -> int:
        smallest_index = -1
        for i, num in enumerate(nums):
            if num % 10 == i:
                return num
        return smallest_index
        
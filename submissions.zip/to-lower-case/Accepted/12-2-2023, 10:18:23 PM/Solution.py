// https://leetcode.com/problems/to-lower-case

class Solution:
    def toLowerCase(self, s: str) -> str:
        return s.lower()
        
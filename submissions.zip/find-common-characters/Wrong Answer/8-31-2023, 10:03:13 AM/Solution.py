// https://leetcode.com/problems/find-common-characters

class Solution:
    def commonChars(self, words: List[str]) -> List[str]:
        result = [2]
        a = words[0]
        b = words[1]
        c = words[2]
        for i in a:
            for j in b:
                for k in c:
                    if i == j == k:
                        result.append(i)
                        break

        return result     
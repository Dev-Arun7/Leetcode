// https://leetcode.com/problems/largest-substring-between-two-equal-characters

class Solution(object):
    def maxLengthBetweenEqualCharacters(self, s):
        """
        :type s: str
        :rtype: int
        """
        temp = 0
        flag = 0
        for i, charector in enumerate(s):
            c = 0
            for j in range(i+1, len(s)):
                if charector != s[j]:
                    c += 1
                else:
                    flag =1
                    if c > temp:
                        temp = c
        return temp if flag == 1 else -1


        

                    


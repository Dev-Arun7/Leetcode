// https://leetcode.com/problems/largest-substring-between-two-equal-characters

class Solution(object):
    def maxLengthBetweenEqualCharacters(self, s):
        """
        :type s: str
        :rtype: int
        """
        temp = -1
        flag = 0
        for i in range(len(s)):
            c = 0
            for j in range(len(s)-1,-1,-1):
                if s[i] == s[j]:
                    flag =1
                    c = j - i -1
                    if c > temp:
                        temp = c
        return temp if flag == 1 else -1
                    
                    

                    
              


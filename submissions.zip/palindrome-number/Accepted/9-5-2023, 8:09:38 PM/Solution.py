// https://leetcode.com/problems/palindrome-number

class Solution(object):
    def isPalindrome(self, x):
        """
        :type x: int
        :rtype: bool
        """
        original_x = x
        reversed_x = 0
        if x < 0:
            return False
        else:
            while x > 0:
                digit = x % 10
                reversed_x = reversed_x * 10 + digit
                x = x // 10
            
        return True if reversed_x == original_x else False
        
// https://leetcode.com/problems/reverse-prefix-of-word


class Solution:
    def reversePrefix(self, word: str, ch: str) -> str:
        result = ""
        for i, char in enumerate(word):
            result += char
            if char == ch:
                result = result[::-1]
                break
    
        result += word[i+1:]
        return result

        
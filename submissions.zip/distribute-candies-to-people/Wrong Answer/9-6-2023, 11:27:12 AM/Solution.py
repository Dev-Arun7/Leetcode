// https://leetcode.com/problems/distribute-candies-to-people

class Solution(object):
    def distributeCandies(self, candies, num_people):
        """
        :type candies: int
        :type num_people: int
        :rtype: List[int]
        """
        pers = [0] * num_people
        n = 0
        for i in range(num_people+1):
            if i == num_people:
                i = 0
            if candies > n + 1:
                pers[i] = pers[i] + n+1
                n = n + 1
                candies = candies - n
            else:
                pers[i] = pers[i] + candies
                return pers
                break
        return pers   
        
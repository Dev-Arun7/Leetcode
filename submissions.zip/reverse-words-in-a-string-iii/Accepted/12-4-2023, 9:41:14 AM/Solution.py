// https://leetcode.com/problems/reverse-words-in-a-string-iii

class Solution:
    def reverseWords(self, s: str) -> str:
        result = ""
        sentance_list = s.split()
        for i in range(len(sentance_list)):
            result += sentance_list.pop(0)[::-1]
            if len(sentance_list) > 0:
                result += " "
        return result
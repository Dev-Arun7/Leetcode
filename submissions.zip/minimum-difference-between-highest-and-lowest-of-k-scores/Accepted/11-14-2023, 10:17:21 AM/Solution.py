// https://leetcode.com/problems/minimum-difference-between-highest-and-lowest-of-k-scores

class Solution:
    def minimumDifference(self, nums: list[int], k: int) -> int:
        sorted_list = sorted(nums)
        l = len(sorted_list)
        diff = sorted_list[-1] - sorted_list[0]
        for i in range(l-k+1):
            x = sorted_list[i+k-1]
            y = sorted_list[i]
            if x - y < diff:
                diff = x - y
        return diff

            
       
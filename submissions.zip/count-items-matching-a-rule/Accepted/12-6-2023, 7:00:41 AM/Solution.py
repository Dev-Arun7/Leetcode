// https://leetcode.com/problems/count-items-matching-a-rule

class Solution:
    def countMatches(self, items: list[list[str]], ruleKey: str, ruleValue: str) -> int:
        count = 0
        if ruleKey == "type":
            key = 0
        elif ruleKey == "color":
            key = 1
        else:
            key = 2
        for i in range(len(items)):
            if items[i][key] == ruleValue:
                count += 1
        return count



        
// https://leetcode.com/problems/check-if-it-is-a-straight-line

class Solution(object):
    def checkStraightLine(self, coordinates):
        """
        :type coordinates: List[List[int]]
        :rtype: bool
        """
        l = len(coordinates)
        d = coordinates[1][1]-coordinates[0][1]
        flag = 0
        for i in range(l-1):
            if (coordinates[i+1][1]-coordinates[i][1]) == (coordinates[i+1][0]-coordinates[i][0]) == d:
                pass
            else:
                flag =1
                
        if flag == 1:
            return False
        else:
            return True
            
            
                
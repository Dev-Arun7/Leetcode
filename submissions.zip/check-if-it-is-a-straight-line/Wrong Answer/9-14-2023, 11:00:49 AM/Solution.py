// https://leetcode.com/problems/check-if-it-is-a-straight-line

class Solution(object):
    def checkStraightLine(self, coordinates):
        """
        :type coordinates: List[List[int]]
        :rtype: bool
        """
        l = len(coordinates)
        
        if l == 2:
            # If there are only two points, they always form a straight line.
            return True
        
        x1, y1 = coordinates[0]
        x2, y2 = coordinates[1]
        
        # Calculate the slope between the first two points
        if x2 - x1 == 0:
            # If the denominator is zero, it's a vertical line, so check all points have the same x-coordinate
            for i in range(2, l):
                if coordinates[i][0] != x1:
                    return False
        else:
            m = (y2 - y1) / (x2 - x1)
            
            for i in range(2, l):
                x, y = coordinates[i]
                # Check if the slope between the current point and the first point is the same as m
                if (x - x1) != 0 and (y - y1) / (x - x1) != m:
                    return False
                elif (x - x1) == 0 and x2 != x1:
                    # Handle the case when the current point and the first point have the same x-coordinate, but the first two points don't
                    return False
        
        return True


# class Solution(object):
#     def checkStraightLine(self, coordinates):
#         """
#         :type coordinates: List[List[int]]
#         :rtype: bool
#         """
#         l = len(coordinates)
#         m = (coordinates[1][1] - coordinates[0][1]) / (coordinates[1][0] - coordinates[0][0])
#         flag = 0
#         for i in range(l-1):
#             if (coordinates[i+1][1]-coordinates[i][1]) / (coordinates[i+1][0]-coordinates[i][0]) == m:
#                 pass
#             else:
#                 flag =1
                
#         if flag == 1:
#             return False
#         else:
#             return True
            
            
                
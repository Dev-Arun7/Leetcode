// https://leetcode.com/problems/check-if-it-is-a-straight-line

def checkStraightLine(coordinates):
    # Check if there are less than 3 points, as any 2 points always form a straight line.
    if len(coordinates) <= 2:
        return True

    # Calculate the slope between the first two points.
    x1, y1 = coordinates[0]
    x2, y2 = coordinates[1]
    initial_slope = (y2 - y1) / (x2 - x1) if x2 - x1 != 0 else float('inf')

    # Check the slopes between all other points and the first point.
    for i in range(2, len(coordinates)):
        x, y = coordinates[i]
        if x - x1 == 0:
            # Handle vertical line case
            if initial_slope != float('inf'):
                return False
        else:
            slope = (y - y1) / (x - x1)
            if slope != initial_slope:
                return False

    return True

# Example usage:
coordinates = [[1,2],[2,3],[3,4],[4,5],[5,6]]
result = checkStraightLine(coordinates)
print(result)  # Output should be True



# class Solution(object):
#     def checkStraightLine(self, coordinates):
#         """
#         :type coordinates: List[List[int]]
#         :rtype: bool
#         """
#         l = len(coordinates)
#         m = (coordinates[1][1] - coordinates[0][1]) / (coordinates[1][0] - coordinates[0][0])
#         flag = 0
#         for i in range(l-1):
#             if (coordinates[i+1][1]-coordinates[i][1]) / (coordinates[i+1][0]-coordinates[i][0]) == m:
#                 pass
#             else:
#                 flag =1
                
#         if flag == 1:
#             return False
#         else:
#             return True
            
            
                
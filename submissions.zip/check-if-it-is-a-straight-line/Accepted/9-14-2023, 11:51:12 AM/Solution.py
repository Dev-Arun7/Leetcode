// https://leetcode.com/problems/check-if-it-is-a-straight-line

class Solution(object):
    def checkStraightLine(self, coordinates):
        """
        :type coordinates: List[List[int]]
        :rtype: bool
        """
        x0 = coordinates[0][0]
        x1 = coordinates[1][0]
        y0 = coordinates[0][1]
        y1 = coordinates[1][1]
        l = len(coordinates)
        for i in range(l):
            x = coordinates[i][0]
            y = coordinates[i][1]
            if(((x1-x0)*(y-y1))!=(x-x1)*(y1-y0)):
                return False
        return True
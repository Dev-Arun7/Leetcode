// https://leetcode.com/problems/find-first-palindromic-string-in-the-array

class Solution:
    def firstPalindrome(self, words: list[str]) -> str:
        for i in words:
            reverse = i[::-1]
            if i == reverse:
                return reverse
        return ""
        
